@@
expression E, SIZE, FLAGS;
@@
+ E = return;
