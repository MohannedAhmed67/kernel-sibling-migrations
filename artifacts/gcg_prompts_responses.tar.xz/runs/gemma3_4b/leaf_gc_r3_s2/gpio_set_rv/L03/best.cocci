@@
expression E, SIZE, FLAGS, NUM;
@@
- E = creg_gpio_set ( gc , offset , val ) ;
+ return creg_gpio_set ( gc , offset , val )
  ...

@@

@@
- E = max77650_gpio_set_value ( gc , offset , value ) ;
+ int regval
  ...

@@

@@
- if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return
+ if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return 0
  ...

@@
 expression E, SIZE, FLAGS, NUM;
identifier ID1;
expression ID2, ID3, ID4;
@@
- E = creg_gpio_set ( gc , offset , val ) ;
+ return ID1 ( ID2 , ID3 , ID4 )
  ...

@@

@@
- E = max77650_gpio_set_value ( gc , offset , value ) ;
+ int regval
  ...

@@
identifier ID1;
expression ID2, ID3, ID4, NUM;
@@
- if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return
+ if ( ID1 ( ID2 , ID3 ) == ID4 ) return NUM
  ...

@@
 expression E, SIZE, FLAGS, NUM;
identifier ID1;
expression ID2, ID3, ID4;
@@
- E = creg_gpio_set ( gc , offset , val ) ;
+ return ID1 ( ID2 , ID3 , ID4 )
  ...

@@

@@
- E = max77650_gpio_set_value ( gc , offset , value ) ;
+ int regval
  ...

@@
identifier ID1;
expression ID2, ID3, ID4, NUM;
@@
- if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return
+ if ( ID1 ( ID2 , ID3 ) == ID4 ) return NUM
  ...
