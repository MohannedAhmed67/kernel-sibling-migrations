@@
expression E, SIZE, FLAGS;
expression ID1, ID2, ID3, ID4, ID5;
@@
- E = inside(ID1, ID2, ID3, ID4, ID5);
+ E = inside(ID1, ID2, ID3, ID4, ID5);
  ...
