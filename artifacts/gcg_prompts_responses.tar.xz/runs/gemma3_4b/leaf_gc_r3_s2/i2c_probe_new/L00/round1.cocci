@@
expression probe_func;
identifier driver;
@@
- . probe_new = probe_func;
+ . driver = { . probe = probe_func };
  ...
