@@
expression E, SIZE, FLAGS;
@@
+ / * * * { function_name } - get RX ring count * @ netdev : network interface device structure * * Return : number of RX rings . * * / static u32 function_name ( struct net_device * netdev ) { struct netdev_priv * np = netdev_priv ( netdev ) ; struct vsi * vsi = np -> vsi ; return vsi -> rss_size ; }
