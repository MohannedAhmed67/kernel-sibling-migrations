rule ethtool_rx_ring_count {
  expression E, SIZE, FLAGS;
  identifier dev, priv, cmd, info, rule_locs, vi, tp, bp, rss_size, num_channels, num_queue_pairs, rxq_cnt, num_online_cpus, channels, params, num_rx_queues, TG3_RSS_MAX_NUM_QS, ID1, ID2, ID3, ID4, ID5, ID6, ID7, ID8, STR;
  constant NUM, ID1, ID2, ID3, ID4, ID5, ID6, ID7, ID8, TG3_RSS_MAX_NUM_QS;

  - E = kmalloc(SIZE, FLAGS);
  + E = kzalloc(SIZE, FLAGS);
  - memset(E, 0, SIZE);

  E = kzalloc(SIZE, FLAGS);
  if (cmd->cmd == ETHTOOL_GRXRINGS) {
    E = channels.params.num_channels;
  } else {
    E = num_online_cpus();
    if (E > TG3_RSS_MAX_NUM_QS) {
      E = TG3_RSS_MAX_NUM_QS;
    }
  }
}
