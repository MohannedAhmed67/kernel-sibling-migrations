@@
expression E, SIZE, FLAGS;
@@
- E = bnx2x_get_rxnfc(dev, info, rules);
+ E = bnx2x_get_rx_ring_count(dev);
  ...
