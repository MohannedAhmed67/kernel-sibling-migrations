@@
expression E, SIZE, FLAGS;
@@
- static int E = vmxnet3_get_rxnfc ( struct net_device * netdev , struct ethtool_rxnfc * info , u32 * rules ) {
+ static u32 E = vmxnet3_get_rx_ring_count ( struct net_device * netdev ) {
  ...
