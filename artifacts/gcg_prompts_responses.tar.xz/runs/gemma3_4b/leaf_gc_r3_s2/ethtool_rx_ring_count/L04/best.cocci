@@
expression E, SIZE, FLAGS;
@@
- E = kmalloc(SIZE, FLAGS);
+ E = kzalloc(SIZE, FLAGS);
  ...
- memset(E, 0, SIZE);
