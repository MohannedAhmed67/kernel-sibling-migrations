@@
expression E, SIZE, FLAGS;
expression STR;
@@
- E.get_rxnfc = STR;
+ E.get_rx_ring_count = STR;
