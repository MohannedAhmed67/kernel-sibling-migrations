@@
expression E, SIZE, FLAGS;
expression STR;
@@
- E.get_rx_ring_count = STR;
+ E.get_rx_ring_count = STR;
