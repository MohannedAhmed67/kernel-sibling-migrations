@@
expression id, index, NUM, STR;
@ida_free E, id, index; @@
identifier ida_index;
@@
- E = ida_simple_remove ( & ida_index , id );
+ E = ida_free ( & ida_index , id );
