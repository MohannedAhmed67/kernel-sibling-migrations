@@
expression ID1, ID2, NUM, STR;
@@
- ida_simple_get ( & ID1 , 0 , NUM , GFP_KERNEL )
+ ida_alloc ( & ID1 , GFP_KERNEL )
  ...

@@
identifier ID2;
expression ID1, NUM;
@@
  ida_simple_get ( & ID1 -> ID2 , NUM , NUM , ID2 ) ==> ida_alloc ( & ID1 -> ID2 , ID2 )

@@
expression ID1, ID2, NUM;
expression ACPI_MAX_DEVICE_INSTANCES;
@@
  ida_simple_get ( ID1 , NUM , ACPI_MAX_DEVICE_INSTANCES , ID2 ) ==> ida_alloc ( ID1 , ID2 )

@@

identifier endp_cnt, lport;
@@
  ida_simple_get ( & lport -> endp_cnt , 0 , 0 , GFP_KERNEL ) ==> ida_alloc ( & lport -> endp_cnt , GFP_KERNEL )

@@

identifier ida_index;
@@
  ida_simple_get ( & ida_index , 0 , 0 , GFP_KERNEL ) ==> ida_alloc ( & ida_index , GFP_KERNEL )
