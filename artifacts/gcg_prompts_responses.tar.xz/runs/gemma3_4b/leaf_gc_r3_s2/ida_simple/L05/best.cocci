@@
expression E, SIZE, FLAGS;
@@
- E = ida_free ( & E , 0 ) ;
+ E = error_free_ida : ida_free ( & E , 0 ) ;
  ...
