rule ida_simple_to_alloc_max {
  - expression ID1, ID2, ID3, ID4, ID5, NUM, STR;
  + expression ID1, ID2, ID3, ID4, ID5, NUM, STR;
  - ID1 = ida_simple_get ( & ID2 , NUM , ID3 , ID4 );
  + ID1 = ida_alloc_max ( & ID2 , ID3 - NUM , ID4 );
}
