@@
expression E, SIZE, FLAGS;
@@
- E = msecs_to_jiffies ( SIZE );
+ E = secs_to_jiffies ( SIZE );
  ...
