@@
expression driver, probe_func;
@@
- . probe_new = probe_func;
+ . probe = probe_func;
  ...
