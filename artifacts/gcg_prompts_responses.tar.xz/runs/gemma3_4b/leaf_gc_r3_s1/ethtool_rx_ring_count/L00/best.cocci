@@
expression E, SIZE, FLAGS;
expression STR1;
@@
- E.get_rx_ring_count = STR1;
+ E.get_rx_ring_count = STR1;
