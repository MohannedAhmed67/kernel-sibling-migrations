@@
expression E, SIZE, FLAGS;
@@
- E = netvsc_get_rxnfc ( inside );
+ E = netvsc_get_rx_ring_count ( inside );
  ...
