@@
expression E, SIZE, FLAGS;
@@
- E = vmxnet3_get_rxnfc ( inside );
+ E = vmxnet3_get_rx_ring_count ( inside );
  ...
