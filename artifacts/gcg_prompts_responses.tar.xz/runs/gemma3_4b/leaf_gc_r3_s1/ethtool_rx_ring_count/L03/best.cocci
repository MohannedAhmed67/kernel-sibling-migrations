@@
expression E, SIZE, FLAGS;
@@
- E = tg3_get_rxnfc ( inside , info , rules );
+ E = bnx2x_get_rx_ring_count ( inside );
  ...
