@@
expression E, SIZE, FLAGS;
@@
- E = bnx2x_get_rxnfc ( inside , info , rules __always_unused );
+ E = bnx2x_get_rx_ring_count ( inside );
  ...
