@@
expression E, SIZE, FLAGS;
@@
+ / * * * ice_get_rx_ring_count - get RX ring count * @ netdev : network interface device structure * * Return : number of RX rings . * * / static u32 ice_get_rx_ring_count ( struct net_device * netdev ) { struct ice_netdev_priv * np = netdev_priv ( netdev ) ; struct ice_vsi * vsi = np -> vsi ; return vsi -> rss_size ; }
