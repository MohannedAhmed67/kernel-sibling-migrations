@@
expression E, SIZE, FLAGS;
@@
+ E = ice_get_rx_ring_count ( netdev );
