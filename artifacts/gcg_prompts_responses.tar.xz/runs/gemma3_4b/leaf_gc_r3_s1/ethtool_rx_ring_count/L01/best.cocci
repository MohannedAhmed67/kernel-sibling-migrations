rule ethtool_rx_ring_count {
  expression E, SIZE, FLAGS;

@@

identifier E;
@@
  - E = kmalloc(SIZE, FLAGS);
  + E = kzalloc(SIZE, FLAGS);

@@

expression E;
@@
  - memset(E, 0, SIZE);
  + return E;
  ...
}
