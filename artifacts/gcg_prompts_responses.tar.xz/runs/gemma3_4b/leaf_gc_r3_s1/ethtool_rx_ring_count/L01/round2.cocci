rule ethtool_rx_ring_count {
  expression E, SIZE, FLAGS;

@@

identifier E;
@@
  + E = kzalloc(SIZE, FLAGS);

@@

identifier E;
@@
  + return E;
  ...
}
