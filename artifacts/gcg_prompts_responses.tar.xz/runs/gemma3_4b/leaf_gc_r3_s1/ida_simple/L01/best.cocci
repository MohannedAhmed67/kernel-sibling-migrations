@@
expression ID1, ID2, NUM, STR;
@@
- ida_simple_get ( & ID1 , 0 , NUM , GFP_KERNEL )
+ ida_alloc ( & ID1 , GFP_KERNEL )
  ...

@@
identifier ID2;
expression ID1, NUM;
@@
- ida_simple_get ( & ID1 -> ID2 , NUM , NUM , ID2 )
+ ida_alloc ( & ID1 -> ID2 , ID2 )
  ...

@@

expression instance_ida;
@@
- ida_simple_get ( instance_ida , 0 , ACPI_MAX_DEVICE_INSTANCES , GFP_KERNEL )
+ ida_alloc ( instance_ida , GFP_KERNEL )
  ...
