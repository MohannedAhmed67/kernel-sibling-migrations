@@
expression E, SIZE, FLAGS;
@@
- E = ida_free ( & E , priv -> id ) ;
+ E = error_free_ida : ida_free ( E , priv -> id ) ;
  ...
