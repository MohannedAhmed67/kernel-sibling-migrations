rule ida_simple_to_alloc_max {
  expression E, SIZE, FLAGS;

@@
identifier ID2, ID3;
expression ID1, ID4, NUM;
@@
  - E = ida_simple_get ( & ID1 -> ID2 , NUM , ID1 -> ID3 , ID4 );
  + E = ida_alloc_max ( & ID1 -> ID2 , ID1 -> ID3 - NUM , ID4 );

@@
}
@@
