@@
expression E, SIZE, FLAGS;
identifier fipsec, halloc;
@@
- E = ida_simple_get ( & fipsec -> halloc , 1 , 0 , GFP_KERNEL );
+ E = ida_alloc_min ( & fipsec -> halloc , 1 , GFP_KERNEL );
  ...

@@

identifier ns_ida;
@@
- E = ida_simple_get ( & ctrl -> subsys -> ns_ida , 1 , 0 , GFP_KERNEL );
+ E = ida_alloc_min ( & ctrl -> subsys -> ns_ida , 1 , GFP_KERNEL );
  ...

@@
identifier ID2, ID3;
expression ID1, ID4, NUM;
@@
- E = ida_simple_get ( & ID1 -> ID2 -> ID3 , NUM , NUM , ID4 );
+ E = ida_alloc_min ( & ID1 -> ID2 -> ID3 , NUM , ID4 );
  ...
