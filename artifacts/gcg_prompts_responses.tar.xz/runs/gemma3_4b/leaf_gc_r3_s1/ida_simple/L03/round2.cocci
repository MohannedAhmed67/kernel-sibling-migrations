@@
expression E, SIZE, FLAGS;
identifier fipsec, halloc;
@@
- E = ida_simple_get ( & fipsec -> halloc , 1 , 0 , GFP_KERNEL );
+ E = ida_alloc_min ( & fipsec -> halloc , 1 , GFP_KERNEL );
  ...

@@
identifier ID2;
expression ID1, ID3, NUM;
@@
- E = ida_simple_get ( & ID1 -> ID2 , NUM , NUM , ID3 );
+ E = ida_alloc_min ( & ID1 -> ID2 , NUM , ID3 );
  ...
