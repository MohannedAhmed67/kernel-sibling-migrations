@@
expression E, SIZE, FLAGS;
identifier reserved_gids, roce;
@@
- E = ida_simple_get ( &dev->roce.reserved_gids.ida, dev->roce.reserved_gids.start, end, GFP_KERNEL);
+ E = ida_alloc_range ( &dev->roce.reserved_gids.ida, dev->roce.reserved_gids.start, end, GFP_KERNEL);
  ...
- memset(E, 0, SIZE);

@@

identifier cntlid_ida, cntlid_max, cntlid_min;
@@
- E = ida_simple_get ( &cntlid_ida, subsys->cntlid_min, subsys->cntlid_max, GFP_KERNEL);
+ E = ida_alloc_range ( &cntlid_ida, subsys->cntlid_min, subsys->cntlid_max, GFP_KERNEL);
  ...
- memset(E, 0, SIZE);

@@
 expression ID1, ID4, ID5, ID6, ID7, SIZE, FLAGS;
 identifier ID2, ID3;
@@
- ID1->ID2->ID3 = E;
+ ID1->ID2->ID3 = E;
