@@
expression id, index, NUM, STR;
@@
- ida_simple_remove ( & id , index );
+ ida_free ( & id , index );
  ...
