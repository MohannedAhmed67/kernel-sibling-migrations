@@
expression pdev, ID1, ID2, STR, CARD_NAME, KBUILD_MODNAME;
@@
- $pdev = pci_request_regions($pdev, ID1);
+ $pdev = pcim_request_all_regions($pdev, STR);
  ...
