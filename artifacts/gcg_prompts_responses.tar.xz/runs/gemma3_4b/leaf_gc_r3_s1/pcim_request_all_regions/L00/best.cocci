@@
expression ID1, STR;
@@
- ID1 = pci_request_regions(pdev, STR);
+ ID1 = pcim_request_all_regions(pdev, STR);
  ...
