@@
expression pdev, STR;
@@
- $pdev = pci_request_regions($pdev, STR);
+ $pdev = pcim_request_all_regions($pdev, STR);
  ...
