@@
expression pdev, ID1, STR;
@@
- $pdev = pci_request_regions($pdev, ID1);
+ $pdev = pcim_request_all_regions($pdev, STR);
  ...
