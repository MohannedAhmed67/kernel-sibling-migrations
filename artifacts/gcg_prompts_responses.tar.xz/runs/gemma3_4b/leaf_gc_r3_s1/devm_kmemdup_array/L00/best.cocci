@@
expression E, SIZE, FLAGS;
expression ID1, ID2, ID3;
@@
- E = devm_kmemdup(ID1, ID2, ID3 * sizeof(*ID3), FLAGS);
+ E = devm_kmemdup_array(ID1, ID2, ID3, sizeof(*ID3), FLAGS);
  ...
