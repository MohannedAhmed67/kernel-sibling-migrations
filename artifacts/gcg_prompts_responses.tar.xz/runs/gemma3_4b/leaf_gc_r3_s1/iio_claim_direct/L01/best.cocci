@@
expression indio_dev, val, len, ret, priv;
@@
- iio_device_release_direct_mode ( indio_dev );
+ iio_device_release_direct ( indio_dev );
  ...
