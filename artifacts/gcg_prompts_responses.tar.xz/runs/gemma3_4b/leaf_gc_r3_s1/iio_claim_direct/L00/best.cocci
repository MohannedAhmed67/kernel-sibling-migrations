@@
expression indio_dev, chan, SIZE, FLAGS;
@@
- ret = iio_device_claim_direct_mode ( indio_dev ) ; if ( ret ) return ret
+ if ( ! iio_device_claim_direct ( indio_dev ) ) return - EBUSY
  ...
- memset(E, 0, SIZE);
