@@
expression fn, SIZE, FLAGS, mask;
@@
- static int tmp006_read_raw(struct iio_dev *indio_dev, struct iio_chan_spec const *channel, int *val, int *val2, long mask) {
+ static int __rtq6056_adc_write_raw ( struct iio_dev * indio_dev , struct iio_chan_spec const * chan , int val , long mask ) {
+   if (ret < 0) return ret;
+   ...
+   return 0;
+};
