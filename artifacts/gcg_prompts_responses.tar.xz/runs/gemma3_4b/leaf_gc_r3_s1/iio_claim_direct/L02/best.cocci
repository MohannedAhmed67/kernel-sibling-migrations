@@
expression indio_dev, channel, val, val2, mask;
expression ID1, ID2;
@@
- iio_device_claim_direct_scoped ( return - EBUSY , indio_dev ) {
+ if ( ! iio_device_claim_direct ( indio_dev ) ) return - EBUSY ;
  ...
- iio_device_claim_direct_scoped ( return - ID1 , ID2 ) {  ==>  if ( ! iio_device_claim_direct ( indio_dev ) ) return - EBUSY ;
+ static int rtq6056_adc_write_raw ( struct iio_dev * indio_dev , struct iio_chan_spec const * chan , int val , int val2 , long mask ) { int ret ; if ( ! iio_device_claim_direct ( indio_dev ) ) return - EBUSY ; ret = __rtq6056_adc_write_raw ( indio_dev , chan , val , mask ) ; iio_device_release_direct ( indio_dev ) ; return ret
