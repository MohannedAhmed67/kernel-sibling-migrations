@@
expression E, SIZE, FLAGS;
expression STR;
@@
- E = inside(STR)({
+  E = inside(STR)({
+   return 0;
+  })
+  ...
