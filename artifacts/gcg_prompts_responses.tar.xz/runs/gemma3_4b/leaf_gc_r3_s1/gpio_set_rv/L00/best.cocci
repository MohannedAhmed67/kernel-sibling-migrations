@@
expression gc, gpio_chip, SIZE, FLAGS;
identifier altr_a10sr_gpio_set;
@@
- gc.set = altr_a10sr_gpio_set;
+ gc.set_rv = altr_a10sr_gpio_set;
  ...
