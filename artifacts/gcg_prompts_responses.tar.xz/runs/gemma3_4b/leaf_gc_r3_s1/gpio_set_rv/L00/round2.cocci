@@
expression gc, gpio_chip, SIZE, FLAGS;
identifier altr_a10sr_gpio_set;
@@
- gc.set = altr_a10sr_gpio_set;
+ gc.set_rv = altr_a10sr_gpio_set;
  ...
+ gc.label = "altr_a10sr_gpio";
+ gc.owner = "THIS_MODULE";
+ gc.get = altr_a10sr_gpio_get;
+ gc.set_rv = altr_a10sr_gpio_set;
+ gc.direction_input = altr_a10sr_gpio_direction_input;
+ gc.direction_output = altr_a10sr_gpio_direction_output;
+ gc.can_sleep = true;
+ gc.ngpio = 12;
+ gc.base = -1;
  ...
