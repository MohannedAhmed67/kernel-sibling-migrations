@@
expression E, SIZE, FLAGS;
identifier GPIO_OUT_OFF, mvchip;
expression gpiod_set_value;
@@
+ return;
- set(priv->clk_gpios->desc[latch], 0);
+ return gpio_latch_set_unlocked ( priv , gpiod_set_value , offset , val );
- gpio_latch_set_unlocked ( priv , gpiod_set_value , offset , val );
+ return __gen_74x164_write_config ( chip );
- __gen_74x164_write_config ( chip );
+ return regmap_update_bits (mvchip -> regs , GPIO_OUT_OFF + mvchip -> offset , BIT (pin) , value ? BIT (pin) : 0 );
- regmap_update_bits ( mvchip -> regs , GPIO_OUT_OFF + mvchip -> offset , BIT (pin) , value ? BIT (pin) : 0 );
+ return sgpio_set_value ( gc , offset , val );
- sgpio_set_value ( gc , offset , val );
