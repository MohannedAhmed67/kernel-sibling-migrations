@@
expression E, SIZE, FLAGS, NUM;
@@
- E = creg_gpio_set ( gc , offset , val ) ;
+ return creg_gpio_set ( gc , offset , val )
  ...

@@

@@
- E = max77650_gpio_set_value ( gc , offset , value ) ;
+ int regval
  ...

@@

@@
- if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return
+ if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return 0
  ...

@@
 expression E, SIZE, FLAGS, NUM;
@@
- E = creg_gpio_set ( gc , offset , val ) ;
+ return creg_gpio_set ( gc , offset , val )
  ...

@@

@@
- E = max77650_gpio_set_value ( gc , offset , value ) ;
+ int regval
  ...

@@

@@
- if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return
+ if ( bcm_kona_gpio_get_dir ( chip , gpio ) == GPIO_LINE_DIRECTION_IN ) return 0
  ...

@@
 expression E, SIZE, FLAGS, NUM;
@@
- E = creg_gpio_set ( gc , offset , val ) ;
+ return creg_gpio_set ( gc , offset , val )
  ...
