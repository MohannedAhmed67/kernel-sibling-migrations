@@
expression ID2, ID3, ID4, SIZE, FLAGS;
identifier ID1;
@@
- static int ID1 ( struct ID2 * ID3 ) {
+ static void ID1 ( struct ID2 * ID3 ) {
  ...
