@@
expression E, SIZE, FLAGS;
expression ID1;
@@
- E.remove = ID1;
+ E.remove_new = ID1;
  ...
