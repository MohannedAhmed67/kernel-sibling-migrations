@@
expression pdev, sp;
@@
- return 0 ;
+ (nothing: the code is deleted)
  ...
