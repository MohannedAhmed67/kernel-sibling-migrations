rule strlcpy_to_strscpy {
  expression E, SIZE, FLAGS;
  + E = strscpy(mdev->name, pinfo->name, SIZE);
  - E = strlcpy(mdev->name, pinfo->name, SIZE);
}
