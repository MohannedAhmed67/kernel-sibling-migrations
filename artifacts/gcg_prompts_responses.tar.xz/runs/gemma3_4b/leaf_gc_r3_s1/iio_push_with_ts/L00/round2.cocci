@@
expression E, SIZE, FLAGS;
@@
- E = iio_push_to_buffers_with_timestamp ( indio_dev , buf , iio_get_time_ns ( indio_dev ) );
+ E = iio_push_to_buffers_with_ts ( indio_dev , &scan , sizeof(scan) , iio_get_time_ns ( indio_dev ) );
