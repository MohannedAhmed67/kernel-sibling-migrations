@@
expression E, SIZE, FLAGS;
@@
- E = iio_push_to_buffers_with_timestamp ( indio_dev , data -> buffer , iio_get_time_ns ( indio_dev ) );
+ E = iio_push_to_buffers_with_ts ( indio_dev , data -> buffer , SIZE , iio_get_time_ns ( indio_dev ) );
