@@
expression ID1, ID2, ID3, ID4, NUM, STR;
@@
- dma_alloc_coherent ( & ID1 -> dev , ID2 , & ID3 , GFP_KERNEL );
+ dma_alloc_coherent ( & ID1 -> dev , ID2 , & ID3 , GFP_KERNEL );
  ...
