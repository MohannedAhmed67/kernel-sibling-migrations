@@
expression ID1, SIZE, FLAGS;
identifier ID2;
identifier ID4;
@@
- dma_alloc_coherent ( ID1 -> ID2 , SIZE , & ID1 -> ID4 )
+ dma_alloc_coherent ( & ID1 -> ID2 -> ID2 , SIZE , & ID1 -> ID4 , FLAGS )
  ...
