@@
expression ID1, ID3, SIZE, FLAGS, GFP;
identifier ID2, ID4;
@@
- dma_alloc_coherent ( ID1 -> ID2 , SIZE , & ID1 -> ID4 , FLAGS )
+ dma_alloc_coherent ( & ID1 -> ID2 -> ID2 , SIZE , & ID1 -> ID4 , GFP )
  ...
