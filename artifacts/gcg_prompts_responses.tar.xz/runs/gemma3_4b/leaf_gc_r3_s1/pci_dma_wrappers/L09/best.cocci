@@
expression ID1, ID2, ID3, ID4, ID5, SIZE, FLAGS, wr;
identifier pdev, dev, dma_addr;
type PCI_DMA_TODEVICE, PCI_DMA_FROMDEVICE, DMA_TO_DEVICE, DMA_FROM_DEVICE;
constant 0;

@@
- ID1 = solo_dev;
+ ID1 = &solo_dev->pdev;
- ID2 = solo_dev->pdev;
+ ID2 = &solo_dev->pdev->dev;
- ID3 = dma_addr;
+ ID3 = dma_addr;
- ID4 = SIZE;
+ ID4 = SIZE;
- ID5 = wr;
+ ID5 = wr;

ret = dma_unmap_single(ID1, ID3, ID4, ID5 ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
