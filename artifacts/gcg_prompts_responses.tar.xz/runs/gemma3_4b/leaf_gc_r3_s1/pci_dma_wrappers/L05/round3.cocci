@@
expression pdev, ent, ID1, ID2, NUM, STR;
identifier dev;
@@
- ID1 = pci_set_dma_mask ( ID1 , DMA_BIT_MASK ( NUM ) );
+ ID1 = dma_set_mask ( &dev->dev , DMA_BIT_MASK ( NUM ) );
  ...
