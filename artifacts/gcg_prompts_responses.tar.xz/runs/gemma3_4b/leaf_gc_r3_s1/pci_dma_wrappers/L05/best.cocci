@@
expression dev, pdev, ent, ID1, ID2, NUM, STR;
@@
- ID1 = pci_set_dma_mask ( ID1 , DMA_BIT_MASK ( NUM ) );
+ ID1 = dma_set_mask ( & ID1 , DMA_BIT_MASK ( NUM ) );
  ...
