@@
expression ID1, SIZE, FLAGS;
identifier ID2;
identifier ID3, ID4, ID5, ID6;
@@
- ID1 = pci_dma_sync_sg_for_cpu ( ID2 -> ID3 , ID2 -> ID4 . ID5 , ID2 -> ID4 . ID6 , PCI_DMA_FROMDEVICE );
+ ID1 = dma_sync_sg_for_cpu ( &ID2 -> ID3 -> ID2 , ID2 -> ID4 . ID5 , ID2 -> ID4 . ID6 , DMA_FROM_DEVICE );
  ...
