@@
expression ID1, ID3, ID4, ID5, NUM, STR;
identifier ID2, ID6;
@@
- ID1->ID2 = pci_map_page(ID1->ID2, ID3, NUM, ID4, ID5); if (pci_dma_mapping_error(ID1->ID2, ID1->ID6)) {
+ ID1->ID2 = dma_map_page(&ID1->ID2->dev, ID3, NUM, ID4, ID5); if (dma_mapping_error(&ID1->ID2->dev, ID1->ID6)) {
  ...
- memset(ID1->ID2, 0, ID4);
+ memset(ID1->ID2, 0, ID4);
