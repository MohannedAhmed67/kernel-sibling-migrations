@@
expression ID1, ID2, ID6, NUM, STR;
identifier ID3, ID4, ID5;
@@
- pci_free_consistent ( ID1, ID2->ID3, ID2->ID4, ID2->ID5 );
+ dma_free_coherent ( &ID1->dev, ID2->ID3, ID2->ID4, ID2->ID5 );
  ...
