@@
expression E, SIZE, FLAGS;
@@
- E->dma_mask = DMA_BIT_MASK(SIZE);
- E->consistent_dma_mask = DMA_BIT_MASK(SIZE);
+ E->dma_mask = dma_set_mask_and_coherent(&E->dev, SIZE);
+ E->consistent_dma_mask = dma_set_mask_and_coherent(&E->dev, SIZE);
  ...
