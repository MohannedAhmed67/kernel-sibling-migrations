@@
expression E, SIZE, FLAGS;
@@
- E->dev->dma_mask = DMA_BIT_MASK(SIZE);
- E->dev->consistent_dma_mask = DMA_BIT_MASK(SIZE);
+ E->dev->dma_mask = dma_set_mask_and_coherent(&E->dev, SIZE);
+ E->dev->consistent_dma_mask = dma_set_mask_and_coherent(&E->dev, SIZE);
  ...
