@@
expression pdev, dma_width, ID1, ID2, NUM, STR;
@@
- pdev->dma_mask = pci_set_dma_mask(pdev, DMA_BIT_MASK(dma_width));
+ pdev->dma_mask = dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(dma_width));
  ...
