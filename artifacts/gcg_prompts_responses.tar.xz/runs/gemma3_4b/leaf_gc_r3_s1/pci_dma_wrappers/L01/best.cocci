@@
expression pdev, ent, dev, err, dma_width, NUM;
@@
- err = pci_set_consistent_dma_mask ( pdev , DMA_BIT_MASK ( NUM ) ) ; if ( err ) { dev_err ( dev , "Unable to get usable DMA configuration\n" ) ; goto err_release_regions ; }
+ err = pci_set_consistent_dma_mask ( pdev , DMA_BIT_MASK ( NUM ) ) ; if ( err ) { dev_err ( dev , "Unable to get usable DMA configuration\n" ) ; goto err_release_regions ; }
  ...
- memset(E, 0, SIZE);
