@@
expression E, SIZE, FLAGS, DMA_DIR, DMA_ADDR;
@@
- E->pdev->dev.dma_mapping_error(E->pdev->dev, dma_addr);
+ dma_mapping_error(&E->pdev->dev, dma_addr);
  ...
