@@
expression E, SIZE, FLAGS, DMA_DIR;
@@
- E->pdev->dev.dma_mapping_error(E->pdev->dev, dma_addr);
+ dma_mapping_error(&E->pdev->dev, dma_addr);
+ dma_addr = dma_map_single(&E->pdev->dev, sys_addr, SIZE, DMA_DIR);
+ if (dma_mapping_error(&E->pdev->dev, dma_addr)) return -ENOMEM;
